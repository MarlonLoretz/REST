package ch.zli.m223.marlon.RestBest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestBestApplicationTests {

	@Test
	void contextLoads() {
	}

}
