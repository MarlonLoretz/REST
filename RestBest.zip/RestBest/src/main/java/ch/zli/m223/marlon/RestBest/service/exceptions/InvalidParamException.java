package ch.zli.m223.marlon.RestBest.service.exceptions;

@SuppressWarnings("serial")
public class InvalidParamException extends RuntimeException {
	
	public InvalidParamException(String message) {
		super(message);
	}
}