package ch.zli.m223.marlon.RestBest.model.memo;

import ch.zli.m223.marlon.RestBest.model.customer.Customer;

public class MemoDto {
	
	public long id;
	public Customer customer;
	public String note;
	public long date;
	
	public MemoDto() {}
	
	public MemoDto(Memo memo) {
		id = memo.getId();
		customer = memo.getCustomer();
		note = memo.getNote();
		date = memo.getDate();
	}
}