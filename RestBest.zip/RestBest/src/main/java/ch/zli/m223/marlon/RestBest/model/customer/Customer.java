package ch.zli.m223.marlon.RestBest.model.customer;

public interface Customer {
	
	Long getId();
	String getName();
}