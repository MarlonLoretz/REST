package ch.zli.m223.marlon.RestBest.model.memo;

import ch.zli.m223.marlon.RestBest.model.customer.Customer;

public interface Memo {
	
	Long getId();
	Customer getCustomer();
	String getNote();
	long getDate();
}