package ch.zli.m223.marlon.RestBest.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import ch.zli.m223.marlon.RestBest.repository.customer.CustomerRepository;


@Component
public class ServerInitialize implements ApplicationRunner{

	@Autowired
	CustomerRepository repo;
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		repo.createCustomer("Lady").getId();
		repo.createCustomer("Leo");
		repo.createCustomer("Loly");
	}

}
