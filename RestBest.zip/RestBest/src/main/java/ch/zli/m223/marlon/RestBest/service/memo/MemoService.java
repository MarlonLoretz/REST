package ch.zli.m223.marlon.RestBest.service.memo;

import java.util.List;

import ch.zli.m223.marlon.RestBest.model.memo.MemoDto;

public interface MemoService {
	
	List<MemoDto> getCustomerMemos(Long customerId);
	MemoDto createMemo(MemoDto memoDto);
	void deleteMemo(Long id);
	
}